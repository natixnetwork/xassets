#!/bin/bash
# TODO: This is a template for creating a new update script
# 1. change the version number
# 2. copy new files
version="1.0.16"








# update system version
echo "$version" > "/root/.version"
