from src.status_manager import get_all_statuses,  StatusManager
import os
import pytest
from pathlib import Path
from src.status_manager import StatusManager, get_all_statuses, ERROR_KEY

# Setup test environment
TEST_DIR = Path(__file__).parent / "test_data"
os.makedirs(TEST_DIR, exist_ok=True)

# Override FILES_MAP for test cases
StatusManager._instance = None  # Reset singleton instance
StatusManager().status_files = {
    "wifi": str(TEST_DIR / "wifi_status.txt"),
}

@pytest.fixture
def status_mgr():
    """ Fixture to provide a fresh instance of StatusManager for each test """
    return StatusManager()

def test_set_status_success(status_mgr):
    """ Test setting a valid status """
    assert status_mgr.set_status("wifi", "connecting") is True
    assert status_mgr.get_status("wifi") == "connecting"

def test_set_status_invalid(status_mgr):
    """ Test setting an invalid status """
    assert status_mgr.set_status("wifi", "invalid_status") is False

def test_set_status_with_error(status_mgr):
    """ Test setting a status that starts with 'Error:' """
    assert status_mgr.set_status("wifi", "Error: failed") is True
    assert status_mgr.get_status("wifi") == "Error: failed"

def test_get_status_code_valid(status_mgr):
    """ Test retrieving the correct status code """
    status_mgr.set_status("wifi", "connecting")
    assert status_mgr.get_status_code("wifi") == 1  # 'connecting' maps to 1

    status_mgr.set_status("wifi", "connected")
    assert status_mgr.get_status_code("wifi") == 2  # 'connected' maps to 2

def test_get_status_code_error(status_mgr):
    """ Test retrieving the status code for an error message """
    status_mgr.set_status("wifi", "Error: connection lost")
    assert status_mgr.get_status_code("wifi") == 99  # Default error handling

def test_get_status_code_unknown(status_mgr):
    """ Test retrieving the status code for an unknown status """
    status_mgr.set_status("wifi", "unknown_status")
    assert status_mgr.get_status_code("wifi") == 99  # '*' fallback in STATUS_MAP

# TODO: change this acording to new BLEStatus data
# def test_get_all_statuses(status_mgr):
#     """ Test getting all statuses as a dictionary """
#     status_mgr.set_status("wifi", "connecting")
#     statuses = get_all_statuses()
#     assert statuses["w"] == 1  # 'connecting' should return code 1
#     status_mgr.set_status("wifi", "Error: whatever")
#     statuses = get_all_statuses()
#     assert statuses["w"] == 99
#     status_mgr.set_status("wifi", "connected")
#     statuses = get_all_statuses()
#     assert statuses["w"] == 2

def test_file_creation(status_mgr):
    """ Test that the file is created if it doesn't exist """
    new_file = TEST_DIR / "new_status.txt"
    status_mgr.status_files["wifi"] = str(new_file)
    assert status_mgr.set_status("wifi", "connecting") is True
    assert new_file.exists()
    new_file.unlink()  # Clean up after test


# def test_():
#     get_all_statuses()
#     status_mgr = StatusManager()
#     status_mgr.get_status_code("wifi")
#     status_mgr.set_status("wifi", "Error: no internet")
#     status_mgr.set_status("wifi", "connecting") #
#     status_mgr.set_status("wifi", "connectingp") # ->