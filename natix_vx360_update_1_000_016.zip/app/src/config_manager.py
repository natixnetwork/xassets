import subprocess
import communication as communication
from message_parser import BLEConfig
from pathlib import Path
import os

script_directory = Path(__file__).parent.parent.parent # "roort" or repo direcorty 




def get_version():
        version_file_path = os.getenv("VERSION_FILE_PATH", f"{script_directory}/.version")
        if not version_file_path:
            print(f"Error: No status file defined for {version_file_path}")
            return None
        
        try:
            with open(version_file_path, "r") as status_file:
                return status_file.read().strip()
        except Exception as e:
            print(f"Error: {version_file_path}: {e}")

            return None
        

def get_active_wifi_SSID():
    ssid = "NO_ACTIVE_WIFI"
    try:
        result = subprocess.run(
            ["nmcli", "-t", "-f", "NAME", "connection", "show", "--active"],
            capture_output=True, text=True, check=True
        )
        
        # Parse the connections and find the one matching the SSID
        ssid =result.stdout.strip()
    except Exception as e:
        print(f"Error: {e}")
        return None
    return ssid

def get_all_configs():
    v = get_version()
    data =   { 
                'id': communication.get_device_id(''),
                'ssid' : get_active_wifi_SSID(),
                'v': v if v else 0
            }

    return BLEConfig(data).to_bytes()
