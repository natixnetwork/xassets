import gpsd, json, time, signal, sys,os 
from dotenv import load_dotenv

load_dotenv('/root/config.env')

gpsd.connect(host="127.0.0.1", port=2947)


def signal_handler(sig, frame):
    print('Stopping GPS logging...')
    sys.exit(0)

signal.signal(signal.SIGTERM, signal_handler)

def read_gps():
    try:
        packet = gpsd.get_current()
        gps_data = {
            "sys_time": int(time.time() * 1000),
            "time": int(packet.time.timestamp() * 1000) if packet.time else None,
            # "time": packet.get_time(),
            "lat": packet.lat,
            "lon": packet.lon,
            "alt": packet.alt,
            "speed": packet.hspeed,
            "climb": packet.climb,
        }
        return gps_data
    
    except gpsd.NoFixError:
        print("Waiting for GPS fix...")
    except Exception as e:
        print(f"Error reading GPS data: {e}")
        
        
def start_logging():
    log_dir = os.getenv("GPS_LOGS_DIRECTORY")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    gps_file_name = os.path.join(log_dir, time.strftime("%Y-%m-%d") + ".log")
    
    while True:
        gps = read_gps()
        if gps is not None:
            with open(gps_file_name, "a+") as gps_log_file:
                gps_log_file.write(json.dumps(gps) + "\n")
        # because the footage video frame rate is 36 fps, we need to log the GPS data at the same/lower rate
        time.sleep(0.03) # sleeping for 30 ms
        
if __name__ == "__main__":
    start_logging()