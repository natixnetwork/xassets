import subprocess

def start_service(service_name: str):
    try:
        subprocess.run(['sudo', 'systemctl', 'start', service_name], check=True)
        print(f"{service_name} started.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to start {service_name}: {e}")

def stop_service(service_name: str):
    try:
        subprocess.run(['sudo', 'systemctl', 'stop', service_name], check=True)
        print(f"{service_name} service stopped.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to stop {service_name}: {e}")
        
def restart_service(service_name: str):
    try:
        subprocess.run(['sudo', 'systemctl', 'restart', service_name], check=True)
        print(f"{service_name} service restarted.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to restart {service_name}: {e}")