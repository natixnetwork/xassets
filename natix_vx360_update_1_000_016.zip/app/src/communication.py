import json, base64, os, time, subprocess, signal, uuid, re
from message_parser import BLEData
from encryption import  get_public_key
from setup_wifi import configure_wifi
from storage import delete_video_files, dir_status
from dotenv import load_dotenv
from service_management import start_service, stop_service, restart_service
from status_manager import StatusManager



# TODO: constant managager add 
load_dotenv('/root/config.env')

def parse(value):
    print(f'value = {value}')
    
    if value == 'get_public_key' or value == b'get_public_key':
        pubKey = "not_a_key" #get_public_key()
        print(f"pubKey={pubKey}")
        return pubKey.encode('utf-8')
    else:
        # pub_key, received_data = decrypt_to_ble_data(value)
        received_data = BLEData.from_bytes(value)
        print(f'commonad recevied: {received_data.cmd}, data={received_data.payload}')
        
        response_payload: str = ""
        if received_data.cmd == 'setup_wifi':
            connected = setup_wifi(received_data.payload)
            response_payload = str(connected)
        elif received_data.cmd == 'copy_start':
            started = copy_start(received_data.payload)
            response_payload = str(started)
        elif received_data.cmd == 'copy_stop':
            stopped = copy_stop(received_data.payload)
            response_payload = str(stopped)
        elif received_data.cmd == 'delete':
            deleted = delete_files(received_data.payload)
            response_payload = str(deleted)
        elif received_data.cmd == 'storage_calc':
            response_payload = status_report(received_data.payload)
        elif received_data.cmd == 'set_schedule':
            saved = set_schedule(received_data.payload)
            response_payload = str(saved)
        elif received_data.cmd == 'get_id': # TODO: check  if config read only works
            mac = get_device_id(received_data.payload)
            response_payload = mac
        elif received_data.cmd == 'update_device':
            response_payload = update_device(received_data.payload)
        elif received_data.cmd == 'set_access_token':
            response_payload = save_access_token(received_data.payload)
        elif received_data.cmd == 'set_aws_access_token':
            response_payload = set_aws_access_token(received_data.payload)
        else: 
            # return encrypt_from_ble_data(pub_key, BLEData(id=received_data.id, cmd=received_data.cmd + '_error', payload="Invalid Command"))
            return BLEData(id=received_data.id, cmd=received_data.cmd + '_error', payload="Invalid Command").to_bytes()
        # TODO:  remove responses
        data = BLEData(id=received_data.id, cmd=received_data.cmd + '_response', payload=response_payload)
        # final_response = encrypt_from_ble_data(pub_key, data)
        final_response = data.to_bytes()
        return final_response


def setup_wifi(payload: str) -> bool:
    config = json.loads(payload)
    ssid = config['ssid']
    psk = config['password']
    return configure_wifi(ssid, psk)

def copy_start(payload: str) -> bool:
    #  DEPRECATED: manually starting the copy_and_watch script
    # process = subprocess.Popen(
    #     ["bash", os.getenv("WATCH_DIR")], 
    #     stdout=subprocess.PIPE, 
    #     stderr=subprocess.PIPE,
    #     preexec_fn=subprocess.os.setpgrp)
    # print(f'process.pid: {process.pid}')
    # with open(os.getenv("COPYING_PID_PATH"), "w") as conf_file:
    #     conf_file.write(str(process.pid))
    
    # running the watch and copy service
    WATCH_COPY_SERVICE_NAME = os.getenv("WATCH_COPY_SERVICE_NAME")
    start_service(WATCH_COPY_SERVICE_NAME)
        
    # running the gps logging service
    GPS_LOGGING_SERVICE_NAME = os.getenv("GPS_LOGGING_SERVICE_NAME")
    start_service(GPS_LOGGING_SERVICE_NAME)
    
    # waiting long enough to ensure that the script has been started!
    time.sleep(5)
    return True


def copy_stop(payload: str) -> bool:
    #  DEPRECATED: manually stopping the copy_and_watch script
    # pid_file_path = os.getenv("COPYING_PID_PATH")
    # if PID file of copying process exists, 
    #   read the PID, 
    #   kill the process 
    #   and delete PID file
    # if os.path.exists(pid_file_path):
    #     with open(pid_file_path, 'rb') as pid_file:
    #         pid_str = pid_file.read()
    #     os.kill(int(pid_str), signal.SIGTERM)    
    #     os.remove(pid_file_path)
        
        
    # stopping the watch and copy service
    WATCH_COPY_SERVICE_NAME = os.getenv("WATCH_COPY_SERVICE_NAME")
    stop_service(WATCH_COPY_SERVICE_NAME)
    
    # start the gps logging service
    GPS_LOGGING_SERVICE_NAME = os.getenv("GPS_LOGGING_SERVICE_NAME")
    stop_service(GPS_LOGGING_SERVICE_NAME)
    
    # just in case!
    time.sleep(2)
    return True

def delete_files(payload: str) -> bool:
    try:
        print(f'delete vide files before: {int(payload)}')
        delete_video_files(int(payload))
        return True
    except Exception as e:
        print(f"Error on delete_videos command: {e}")
        return False

def status_report(payload: str) -> str:
    try:
        is_tesla_dir = payload.lower() == 'true'
        print(f'dir status: {is_tesla_dir}')
        status = dir_status(is_tesla_dir)
        return json.dumps(status)
    except Exception as e:
        print(f"Error on status_report command: {e}")
        return f"Error on status_report command: {e}"

def set_schedule(payload: str) -> bool:
    schedule_file_path = os.getenv("UPLOAD_SCHEDULE_PATH")
    if os.path.exists(schedule_file_path):
        os.remove(schedule_file_path)
    time.sleep(1)
    with open(schedule_file_path, "w") as conf_file:
        conf_file.write(payload)
    time.sleep(1)
    return True

def get_device_id(payload: str) -> str:
    mac_address = ""
    try:
        with open('/sys/class/net/wlan0/address', 'r') as f:
            mac_address = f.read().strip()
        print(f'mac address = {mac_address}')
        return mac_address
    except Exception as e:
        print(f"Error getting mac address: {e}")
        return mac_address

def update_device(payload: str) -> str:
    status_mngr = StatusManager()
    try:
        restart_service("greengrass.service")
        time.sleep(5)
        script_path = os.getenv("UPDATE_DEVICE_SCRIPT_PATCH")
        process = subprocess.Popen(['bash', script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        if process.returncode == 0:
            return True
        else:
            err = f"Error: update failed.  {stderr.decode('utf-8')}"
            status_mngr.set_status ("update", err)
            return  False
    except Exception as e:
        err = f"Error: issue during update  {str(e)}"
        status_mngr.set_status ("update", err)
        return  False

def save_access_token(payload: str) -> str:
    access_token_path = os.getenv("ACCESS_TOKEN_PATH")
    try:
        with open(access_token_path, "w") as token_file:
            token_file.write(payload)
        return "Access token saved successfully."
    except Exception as e:
        print(f"Error saving access token: {e}")
        return f"Error saving access token: {e}"
    
def set_aws_access_token(payload: str) -> str:
    try:
        config = json.loads(payload)
        aws_access_key_id = config['aws_access_key_id']
        aws_secret_access_key = config['aws_secret_access_key']
        # os.environ['AWS_ACCESS_KEY_ID'] = aws_access_key_id
        # os.environ['AWS_SECRET_ACCESS_KEY'] = aws_secret_access_key

        script_path = os.getenv("AWS_INSTALLATION_PATH")
        process = subprocess.Popen(['bash', script_path, aws_access_key_id, aws_secret_access_key], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()

        if process.returncode == 0:
            print ("Greengrass installation successful.")
            return  True 
        else:
            print (f"Greengrass installation failed. Error: {stderr.decode('utf-8')}")
            return False
    except Exception as e:
        print ( f"Error during Greengrass installation: {str(e)}")
        return False
    