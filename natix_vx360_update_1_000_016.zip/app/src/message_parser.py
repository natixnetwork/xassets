from dataclasses import dataclass
from typing import Optional
import json
import msgpack

@dataclass
class BLEData:
    id: int
    cmd: str    
    payload: Optional[str] = None
    
    def to_bytes(self):
        return msgpack.packb({'id': self.id, 'cmd': self.cmd, 'p': self.payload})
    
    @staticmethod
    def from_bytes(data):
        decoded = msgpack.unpackb(data)
        return BLEData(id=decoded['id'], cmd=decoded['cmd'], payload=decoded.get('p'))

@dataclass
class BLESataus:
    data: dict
    def to_bytes(self):
        return msgpack.packb(self.data)
    
@dataclass  
class BLEConfig:
    data: dict
    def to_bytes(self):
        return msgpack.packb(self.data)