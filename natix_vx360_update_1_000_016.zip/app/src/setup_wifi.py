import subprocess, nmcli, time, os
from service_management import restart_service
from status_manager import StatusManager

def check_wifi_connection() -> bool:    
    try:
        # Use curl to test connectivity
        response = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "https://www.google.com"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )

        http_status = response.stdout.decode().strip()

        if http_status == "200":
            print("Successfully connected to the Internet.")
            return True
        else:
            print(f"Failed to connect to the Internet. HTTP Status: {http_status}")
            return False
    except Exception as e:
        print(f"rror checking Wi-Fi connection: {e}")
        return False

    

def configure_wifi(wifi_name, password) -> bool:
    wifi_status_path = os.getenv("WIFI_STATUS_PATH")
    print(f"{wifi_name} ,{password}")
    try:
        StatusManager().set_status ("wifi",  "connecting")
        
        result = subprocess.run(
            ["nmcli", "-t", "-f", "NAME,DEVICE,TYPE,STATE", "connection", "show"],
            capture_output=True, text=True, check=True
        )
        
        # Parse the connections and find the one matching the SSID
        for line in result.stdout.splitlines():
            name, device, conn_type, state  = line.split(":")
            if name == wifi_name:
                
                if state=='activated' and check_wifi_connection():
                    StatusManager().set_status ("wifi",  "connected")
                    return True

                print(f"{wifi_name} already exists and not connectd in the known networks. Deleting the existing connection.")
                subprocess.run(["nmcli", "connection", "delete", wifi_name], check=True)

        subprocess.run(["nmcli", "dev", "wifi"], check=True)
        time.sleep(1)
        # Create the connection profile
        
        subprocess.run(["nmcli", "dev", "wifi", "connect", wifi_name, "password", password], check=True)

        print(f"Successfully connected to {wifi_name}")
        connected_to_internet = check_wifi_connection()
        
        
        if connected_to_internet:
            StatusManager().set_status ("wifi",  "connected")
        else:
            StatusManager().set_status ("wifi",  "Error: no internet")
            
        return connected_to_internet
    except Exception as e:
        print(f"Error connecting to {wifi_name}: {e}")
        StatusManager().set_status ("wifi",  f"Error: connecting to {wifi_name}: {e}")
        return False