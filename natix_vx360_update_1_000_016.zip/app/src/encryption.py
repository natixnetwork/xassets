from cryptography.hazmat.primitives.serialization import load_der_public_key
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os
import base64
from key import load_private_key, load_public_key
import binascii
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat


def extract_shared_key(sender_public_key_der_hex: str) -> str:
    my_prv_key = load_private_key()
    sender_public_key_der = bytes.fromhex(sender_public_key_der_hex)
    
    # print(f'sender_public_key_der = {binascii.hexlify(sender_public_key_der)}')
    
    # curve = ec.SECP256R1()
    # key_size = (curve.key_size + 7) // 8  # Convert bits to bytes
    # x = int.from_bytes(sender_public_key_der[1:1 + key_size], byteorder='big')
    # y = int.from_bytes(sender_public_key_der[1 + key_size:], byteorder='big')

    # public_numbers = EllipticCurvePublicNumbers(x, y, curve)
    # sender_public_key = public_numbers.public_key(default_backend())
    
    # print(f'sender_public_key = {binascii.hexlify(sender_public_key.public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo))}')
    
    
    sender_public_key = load_der_public_key(sender_public_key_der, backend=default_backend())
    print(f'sender_public_key = {binascii.hexlify(sender_public_key.public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo))}')
    
    
    shared_key = my_prv_key.exchange(ec.ECDH(), sender_public_key)

    # Hash the shared secret using SHA-256
    digest = hashes.Hash(hashes.SHA256())
    digest.update(shared_key.hex().encode('utf-8'))
    hashed_secret = digest.finalize()

    # The hashed_secret is now a 256-bit (32-byte) AES key
    aes_key = hashed_secret
    return aes_key


def decrypt_message(encrypted_message_base64: str, sender_public_key: str) -> str:
    derived_key = extract_shared_key(sender_public_key)
    
    decoded_message = base64.b64decode(encrypted_message_base64)
    # because the IV length is 16 bytes, so the base64 encoded length would be 24
    iv = decoded_message[:16]
    ciphertext = decoded_message[16:]
    
    cipher = Cipher(algorithms.AES(derived_key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()

    # Remove padding (PKCS7)
    padding_length = padded_plaintext[-1]
    plaintext = padded_plaintext[:-padding_length]
    return plaintext.decode('utf-8')



def encrypt_message(plaintext: str, sender_public_key: str) -> str:
    derived_key = extract_shared_key(sender_public_key)
    iv = os.urandom(16)
    
    cipher = Cipher(algorithms.AES(derived_key), modes.CBC(iv), backend=default_backend())
    encrypter = cipher.encryptor()
    
    # add PKCS7 padding
    padding_length = 16 - (len(plaintext) % 16)
    padded_plaintext = plaintext.encode('utf-8') + bytes([padding_length] * padding_length)
    
    cipher_text = encrypter.update(padded_plaintext) + encrypter.finalize()
    
    result = base64.b64encode(iv + cipher_text).decode('utf-8')
    return result

def get_public_key() -> str:
    return load_public_key()