import sys, logging, asyncio, threading, subprocess
from typing import Any, Dict, Union
from bless import ( BlessServer, BlessGATTCharacteristic, GATTCharacteristicProperties, GATTAttributePermissions,)
import communication as communication
from config_manager import get_all_configs
from status_manager import get_all_statuses

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(name=__name__)

# *** static variables
# TODO: create the constant managager
SERVER_NAME = "NATIX VX360"
SERVICE_UUID = "12345678-1234-5678-1234-56789abcdef0"
COMMAND_CHARACTERISTIC_UUID = "12345678-1234-5678-1234-56789abcdef1"
STATUS_CHARACTERISTIC_UUID = "12345678-1234-5678-1234-56789abcdef2"
CONFIG_CHARACTERISTIC_UUID =  "12345678-1234-5678-1234-56789abcdef3"
READ_MTU_SIZE = 184
WRITE_MTU_SIZE = 184
READ_CHUNKS = []
WRITE_CHUNKS = []

# NOTE: Some systems require different synchronization methods.
trigger: Union[asyncio.Event, threading.Event]
# if sys.platform in ["darwin", "win32"]:
    # trigger = threading.Event()
# else:
trigger = asyncio.Event()

# ** Writing to Bluetooth characteristic
def write_message(characteristic: BlessGATTCharacteristic, **kwargs):
    global WRITE_CHUNKS
    print(f"{str(characteristic.uuid)}")
    if  str(characteristic.uuid) == STATUS_CHARACTERISTIC_UUID:
        message = get_all_statuses()
        characteristic.value = message
        return message

    # TODO: Removed write for COMMAND_CHARACTERISTIC_UUID
    # TODO: Check if we need write in chunks of 180 is safe for all phones
    if str(characteristic.uuid) == COMMAND_CHARACTERISTIC_UUID and WRITE_CHUNKS:
        message_to_write = WRITE_CHUNKS.pop(0)
        characteristic.value = message_to_write
        print(f"chunk no: {len(WRITE_CHUNKS)}, message to be read: {message_to_write}")
        return message_to_write
    
    if str(characteristic.uuid) ==CONFIG_CHARACTERISTIC_UUID:
        return get_all_configs()
    else:
        
        return b'no value'

        
# ** Reading from Bluetooth characteristic
def read_message(characteristic: BlessGATTCharacteristic, value: Any, **kwargs):
    global READ_MTU_SIZE, WRITE_MTU_SIZE, READ_CHUNKS, WRITE_CHUNKS
    characteristic.value = value
    
    # converting the byte array to string
    if value.startswith(b'bluetooth_mtu_'):
        print(f"read_message: {value}")
        actual_mtu_size = int(value[len(b'bluetooth_mtu_'):])
        READ_MTU_SIZE = actual_mtu_size - 3 # because on the app side, there is a 3 bytes ATT header for write
        WRITE_MTU_SIZE = actual_mtu_size - 1 
        logger.debug(f"MTU received: {actual_mtu_size}")
        READ_CHUNKS.clear()
    else:
        OUR_CUSTOM_END_PADDING_SIZE = 3
        if len(value) >= (READ_MTU_SIZE) and value.endswith(bytes('@' * OUR_CUSTOM_END_PADDING_SIZE, 'utf-8')):
            partial_message = value[:READ_MTU_SIZE - OUR_CUSTOM_END_PADDING_SIZE]
            READ_CHUNKS.append(partial_message)
            print(f'partial = {partial_message}')
            return
        if READ_CHUNKS:
            joined_message = b''.join(READ_CHUNKS)
            value = joined_message + value
            print(f'joined message = {value}')
            READ_CHUNKS.clear()

        result = communication.parse(value)
        WRITE_CHUNKS = [result[i:i + WRITE_MTU_SIZE] for i in range(0, len(result), WRITE_MTU_SIZE)]
        print(f"result={result}, write_chunks={WRITE_CHUNKS}")

    
        
        
# ** Main loop for the bluetooth server
async def run(loop):
    trigger.clear()


    # NOTE - Method 1: add new service and characteristic
    # create a new BLE server object
    server = BlessServer(name=SERVER_NAME, loop=loop)
    # setting the read/write handlers
    server.read_request_func = write_message
    server.write_request_func = read_message

    # add new service
    await server.add_new_service(SERVICE_UUID)
    
    # TODO: Removed read and inidicate permission
    # characteristic flags and permissions
    char_flags = (
        GATTCharacteristicProperties.read
        | GATTCharacteristicProperties.write
        | GATTCharacteristicProperties.indicate
        | GATTCharacteristicProperties.write_without_response
    )
    char_flags_read = (
        GATTCharacteristicProperties.read
    )
    permissions = GATTAttributePermissions.read_encryption_required | GATTAttributePermissions.write_encryption_required
    # add new characteristic
    await server.add_new_characteristic(SERVICE_UUID, COMMAND_CHARACTERISTIC_UUID, char_flags, None, permissions)
    await server.add_new_characteristic(SERVICE_UUID, STATUS_CHARACTERISTIC_UUID, char_flags_read, None, permissions)
    await server.add_new_characteristic(SERVICE_UUID, CONFIG_CHARACTERISTIC_UUID, char_flags_read, None, permissions)
    
    
    
    await server.start()
    logger.debug("Starting BLE server...")
    
    # powering on and disabling agent for connecting without pairing
    subprocess.run(["bluetoothctl", "power", "on"], check=True)
    subprocess.run(["bluetoothctl", "agent", "off"], check=True)
    
    # TODO: Store Ble-service status in a file

    # based on this script's runtime type (is it thread or not!)
    if trigger.__module__ == "threading":
        trigger.wait()
    else:
        await trigger.wait()
        
    await asyncio.sleep(2)
    logger.debug("Updating")
    server.get_characteristic(COMMAND_CHARACTERISTIC_UUID).value = bytearray(b"i")
    server.get_characteristic(STATUS_CHARACTERISTIC_UUID).value = bytearray(b"i")
    server.get_characteristic(CONFIG_CHARACTERISTIC_UUID).value = bytearray(b"i")
    server.update_value(SERVICE_UUID, COMMAND_CHARACTERISTIC_UUID)
    server.update_value(SERVICE_UUID, STATUS_CHARACTERISTIC_UUID)
    server.update_value(SERVICE_UUID, CONFIG_CHARACTERISTIC_UUID)
    await asyncio.sleep(5)
    await server.stop()


# instantiating the server and running the loop
loop = asyncio.get_event_loop()
loop.run_until_complete(run(loop))