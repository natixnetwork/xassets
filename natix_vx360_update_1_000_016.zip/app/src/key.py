import os, json
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import load_der_private_key
from cryptography.hazmat.backends import default_backend

from dotenv import load_dotenv
load_dotenv('/root/config.env')

def load_public_key():
    # Define the file paths
    private_key_file = os.getenv("PRIVATE_KEY_FILE")
    public_key_file = os.getenv("PUBLIC_KEY_FILE")
        
    # Check if the public key file exists
    if os.path.exists(public_key_file):
        # If the public key exists, read and return it
        with open(public_key_file, 'rb') as pub_file:
            public_key = pub_file.read()
        result = public_key.hex()
        print(f'Public key retrieved successfully. {result}')
        return result
    else:
        # If the public key doesn't exist, generate a new key pair
        print('Public key not found. Generating a new ECDSA key pair...')
        
        # Generate ECDSA private key
        private_key = ec.generate_private_key(ec.SECP256R1())  # SECP256R1 is a common ECDSA curve
        
        # Serialize and save the private key to the file
        with open(private_key_file, 'wb') as priv_file:
            priv_file.write(
                private_key.private_bytes(
                    encoding=serialization.Encoding.DER,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                )
            )
        print('Private key saved successfully.')
            
        # Serialize and save the public key to the file
        public_key = private_key.public_key()            
        public_key_der = public_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )            
        with open(public_key_file, 'wb') as pub_file:
            pub_file.write(public_key_der)
        print(f'Public key saved successfully. {public_key_der.hex()}')
                        
        # Return the public key
        return public_key_der.hex()
        


def load_private_key() -> ec.EllipticCurvePrivateKey:
    """
    Load the private key from the .private_key file.
    Raises an error if the file does not exist.
    """
    private_key_file = os.getenv("PRIVATE_KEY_FILE")
    if not os.path.exists(private_key_file):
        raise FileNotFoundError("Private key file '.private_key' not found.")
    
    with open(private_key_file, 'rb') as f:
        return load_der_private_key(f.read(), password=None, backend=default_backend())