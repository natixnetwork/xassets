import os
import threading
from pathlib import Path
from message_parser import BLESataus
import json

script_directory = Path(__file__).parent.parent.parent # "roort"
# TODO: constant managager add 
ERROR_KEY = "Error:"
FILES_MAP= {"wifi": os.getenv("WIFI_STATUS_PATH", f"{script_directory}/.wifi_status"),
            #"collection": os.getenv("COLLECTION_STATUS_PATH", f"{script_directory}/collection_status"), 
            "update": os.getenv("UPDATE_STATUS_PATH", f"{script_directory}/.update_status"),
            "storage" :  os.getenv("WATCH_DIR_STORAGE_CACHE", f"{script_directory}/.watch_dir_info.json"), 
            "storageTesla" :  os.getenv("WATCH_DIR_TESLA_STORAGE_CACHE", f"{script_directory}/.watch_tesla_dir_info.json"), 
            "green_grass" :  os.getenv("UPDATE_STATUS_PATH", f"{script_directory}/.update_status") +'.greengrass'
            }
STATUS_MAP = {
              "wifi": {
                    "connecting": 1, 
                    "connected": 2,
                    "*": 99,#  any issues,
                },
                #  "collection": {
                #     "processing": 1
                #     "started": 2, 
                #     "stoped": 3,
                #     "*": 99,#  any issues,
                    
                # },
                "update": {
                    "updating": 1, 
                    "updated": 2,
                    "rolled_back": 3, 
                    "*": 99,#  any issues,
                },
                "green_grass": {
                    "installing": 1, 
                    "installed": 2,
                    "failed": 3, 
                    "*": 99,#  any issues,
                },
                "storage": {
                    "***": -1, 
                },
                "storageTesla" : {
                    "***": -1, 
                }

            }
class StatusManager:
    _instance = None
    _lock = threading.Lock()  # Ensures thread safety for multiple calls

    def __new__(cls):
        """ Singleton instance creation """
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(StatusManager, cls).__new__(cls)
                cls._instance.status_files = FILES_MAP
                # Define different status mappings for each key
                cls._instance.status_codes = STATUS_MAP
        return cls._instance

    def set_status(self, key, status):
        """ Write status to the corresponding file """
        status_file_path = self.status_files.get(key)
        
        if not status_file_path:
            print(f"Error: No status file defined for {key}")
            return False
        
        try:
            status_list = self.status_codes.get(key, None)
            all_keys = list(status_list.keys())
            if status_list and (all_keys[0] == "***" or status in all_keys or status.startswith(ERROR_KEY)) :
                with open(status_file_path, "w") as status_file:
                    if isinstance(status, dict):  
                        status = json.dumps(status)
                    status_file.write(status)
                print(f"Updated {key} status: {status}")
                return True
            else:
                print(f"no predefined value as {status} for {key}")
        except Exception as e:
            print(f"Error: {e}")
        
        return False

    def get_status(self, key):
        """ Read status from the corresponding file """
        status_file_path = self.status_files.get(key)
        if not status_file_path:
            print(f"Error: No status file defined for {key}")
            return None
        
        try:
           
            with open(status_file_path, "r") as status_file:
                return status_file.read().strip()
        except Exception as e:
            print(f"Error {status_file_path}: {e}")
            return None

    def get_status_code(self, key):
        """ Get numerical status code for a given key (WiFi, Bluetooth, Server) """
        status_code = 0  # Default unknown status
        try:
            status = self.get_status(key)  # Get the status text
    
            # Look up the corresponding code for this status
            status_map = self.status_codes.get(key, None)  # Get the mapping for the keyex
            
            if  status  and status_map:
                status_code = status_map.get(status, status_map.get('*',0))  # Default to 0 if status not found
            
        except Exception as e:
            print(f"Error retrieving status code for {key}: {e}")

        return status_code
    
def  get_all_statuses():

    default_dir_status =  {
            "t": 0,
            "u": 0,
            "c": 0
    }
    
    status_mngr = StatusManager()
    storage = status_mngr.get_status("storage") 
    tesla_storage = status_mngr.get_status("storageTesla")
    data=  {
        "w": status_mngr.get_status_code("wifi"),
        "s":  storage if storage else default_dir_status,
        "st": tesla_storage if tesla_storage else default_dir_status,
        #"c": status_mgr.get_status("collection"),
        "u": get_final_update_status()
        }
    return BLESataus(data).to_bytes()

def get_final_update_status():
    status_mngr = StatusManager()
    gs = status_mngr.get_status_code("green_grass")
    u = status_mngr.get_status_code("update")
    # toDO: Check this?
    r = gs if gs == 1 else (u if gs == 2 else 99) # 1-> ing 2-> done successfully  99-> any error
    return r