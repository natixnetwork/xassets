import os, shutil, json
import subprocess
from dotenv import load_dotenv
load_dotenv('/root/config.env')
from status_manager import StatusManager

# TODO: constant managager add 
STORAGE_STATUS_KEY = "storage"
STORAGE_TESLA_STATUS_KEY = "storageTesla"
def delete_video_files(delete_before_epoch_time = 0):
    # TODO: constant managager add 
    dir_path = os.getenv("DEST_DIR")
    try:
        for filename in os.listdir(dir_path):
            file_path = os.path.join(dir_path, filename)
            if not os.path.isfile(file_path):
                continue
            if delete_before_epoch_time > 0:
                file_mtime = os.path.getmtime(file_path) * 1000
                if file_mtime >= delete_before_epoch_time:
                    continue
            try:
                os.remove(file_path)
                print(f"Deleted: {file_path}")
            except Exception as e:
                print(f"Error deleting file {file_path}: {e}")
    
    except Exception as e:
        print(f"Error accessing the directory: {e}")
        

def dir_status(tesla_dir: bool = False):
    if tesla_dir: 
        return tesla_dir_status()
    
    dir_path = os.getenv("DEST_DIR")
    if not os.path.exists(dir_path):
        raise FileNotFoundError(f"The directory {dir_path} does not exist.")
    total, used, free = shutil.disk_usage(dir_path)
    footage_size =0
    files_count = 0
    try:
        result = subprocess.run(
            ["du", "-sb", dir_path],
            capture_output=True, text=True, check=True
        )
        
        # Extract only the size part
        footage_size = int(result.stdout.strip().split("\t")[0])
    
        print(f"Size of '{dir_path}': {footage_size}")
        
        files_count = sum(len([f for f in files if f.endswith('.mp4')]) for _, _, files in os.walk(dir_path))

    except subprocess.CalledProcessError as e:
        print(f"Error getting directory size: {e}")

    

    result =  {
        "t": round((free + footage_size) / (1024 **3),2) ,
        "u": round(footage_size / (1024 **3), 2),
        "c": files_count
    }
    StatusManager().set_status (STORAGE_STATUS_KEY, result )
    return result
    
    
def tesla_dir_status():
    # Path to the JSON file
    json_file = os.getenv("WATCH_DIR_TESLA_STORAGE_CACHE") # 

    if not os.path.exists(json_file):
        # Return zeros if file is not found
        return {
            "t": 0,
            "u": 0,
            "c": 0
        }
    # Load the JSON data
    with open(json_file, 'r') as file:
        data = json.load(file)

    total = data.get('total_size', 0)
    used = data.get('total_used', 0)
    free = data.get('total_free', 0)
    files_count = data.get('file_count', 0)
    
    # Ensure values are integers
    total = int(total) if isinstance(total, int) else 0
    used = int(used) if isinstance(used, int) else 0
    free = int(free) if isinstance(free, int) else 0
    files_count = int(files_count) if isinstance(files_count, int) else 0
    
    # Calculate percentage & used
    percentage_used = (used / total) * 100 if total > 0 else 0
    
    # GB and remove free and percentage 
    result = {
        "t": round(total / (1024 *1024), 2)	,
        "u": round(used/ (1024 * 1024), 2),
        "c": files_count
    }
    StatusManager().set_status (STORAGE_TESLA_STATUS_KEY, result )
    
    # Return the result as a dictionary
    return  result
